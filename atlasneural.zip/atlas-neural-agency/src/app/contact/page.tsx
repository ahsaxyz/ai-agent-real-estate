"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

const suggestedPrompts = [
  "Analyze Miami luxury market",
  "Find undervalued commercial assets",
  "Generate portfolio strategy",
  "Compare international yield opportunities",
];

const agentResponses: Record<string, string> = {
  "Analyze Miami luxury market": "Based on current neural analysis, the Miami luxury market shows exceptional strength with 96.1% confidence. Key findings:\n\n• Average appreciation: +12.4% YoY\n• Strong institutional demand from tech migration\n• Tax-friendly environment driving HNW inflows\n• Projected 5-year yield: 7.4%\n\nTop opportunity: Miami Beach waterfront properties in the $15-25M range.",
  "Find undervalued commercial assets": "Neural scan complete. Identified 23 undervalued commercial opportunities:\n\n• Dubai: Office towers in Business Bay (Score: 94.2)\n• London: Retail spaces in Canary Wharf (Score: 88.7)\n• Singapore: Mixed-use developments in CBD (Score: 91.5)\n\nBest value: Dubai Business Bay - projected 18% appreciation over 3 years.",
  "Generate portfolio strategy": "Portfolio optimization analysis complete:\n\n• Recommended allocation: 40% luxury residential, 30% commercial, 30% mixed-use\n• Geographic diversification: 50% US, 30% Middle East, 20% Europe/Asia\n• Target IRR: 14.8%\n• Risk-adjusted score: 92.3\n\nStrategy emphasizes growth markets with strong fundamentals.",
  "Compare international yield opportunities": "Comparative yield analysis across 10 markets:\n\n1. Istanbul: 9.2% (Medium-High risk)\n2. Dubai: 8.4% (Low risk)\n3. Miami: 7.4% (Low risk)\n4. Singapore: 6.2% (Low risk)\n5. London: 5.9% (Low risk)\n\nRecommendation: Dubai offers optimal risk-reward profile for institutional portfolios.",
};

export default function ContactPage() {
  const [messages, setMessages] = useState([
    {
      role: "agent",
      content: "Neural Agent online. I'm your autonomous intelligence interface. How can I assist with real estate intelligence today?",
      timestamp: new Date(),
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = (content: string) => {
    if (!content.trim()) return;

    // Add user message
    const userMessage = {
      role: "user",
      content,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsTyping(true);

    // Simulate agent response
    setTimeout(() => {
      const response = agentResponses[content] ||
        "Intelligence query received. Our neural network is processing your request. A detailed analysis report will be generated shortly. For immediate assistance, please schedule a consultation with our team.";

      const agentMessage = {
        role: "agent",
        content: response,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, agentMessage]);
      setIsTyping(false);
    }, 2000);
  };

  return (
    <main className="min-h-screen">
      <Navbar />

      <div className="pt-20 pb-12 px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center space-x-2 px-4 py-2 glassmorphism-light rounded-full mb-6">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-sm text-gray-300 font-medium uppercase tracking-wider">
                Neural Agent Online
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Intelligence Interface
              </span>
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Connect with our autonomous neural agents for real-time market intelligence
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Chat Interface */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="lg:col-span-2"
            >
              <div className="glassmorphism rounded-lg overflow-hidden h-[700px] flex flex-col">
                {/* Chat Header */}
                <div className="p-6 border-b border-gray-800">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center">
                          <span className="text-black font-bold">AI</span>
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-black" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-white">Atlas Neural Agent</h3>
                        <p className="text-xs text-green-400">Active • Real-time intelligence</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 p-6 overflow-auto space-y-4">
                  <AnimatePresence>
                    {messages.map((message, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[80%] ${
                            message.role === "user"
                              ? "bg-gradient-to-r from-yellow-400 to-yellow-600 text-black"
                              : "glassmorphism-light text-gray-200"
                          } p-4 rounded-lg`}
                        >
                          <div className="text-sm whitespace-pre-line">{message.content}</div>
                          <div className={`text-xs mt-2 ${
                            message.role === "user" ? "text-black/70" : "text-gray-500"
                          }`}>
                            {message.timestamp.toLocaleTimeString()}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {isTyping && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex justify-start"
                    >
                      <div className="glassmorphism-light p-4 rounded-lg">
                        <div className="flex space-x-2">
                          <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" />
                          <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                          <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Suggested Prompts */}
                {messages.length === 1 && (
                  <div className="px-6 pb-4">
                    <div className="text-xs text-gray-500 uppercase tracking-wider mb-3">
                      Suggested Intelligence Queries
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {suggestedPrompts.map((prompt) => (
                        <button
                          key={prompt}
                          onClick={() => handleSendMessage(prompt)}
                          className="text-left px-3 py-2 text-xs bg-black/30 border border-gray-800 rounded hover:border-yellow-400/50 text-gray-300 hover:text-white transition-colors"
                        >
                          {prompt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Input */}
                <div className="p-6 border-t border-gray-800">
                  <div className="flex space-x-3">
                    <input
                      type="text"
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && handleSendMessage(inputValue)}
                      placeholder="Enter intelligence query..."
                      className="flex-1 px-4 py-3 bg-black/30 border border-gray-800 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-yellow-400/50 transition-colors"
                    />
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleSendMessage(inputValue)}
                      className="px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-600 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-yellow-400/20 transition-all"
                    >
                      Send
                    </motion.button>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Consultation Forms */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              {/* Request Consultation */}
              <div className="glassmorphism p-6 rounded-lg">
                <h3 className="text-xl font-bold text-white mb-4">Request Consultation</h3>
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Full Name</label>
                    <input
                      type="text"
                      className="w-full px-4 py-2 bg-black/30 border border-gray-800 rounded text-white placeholder-gray-500 focus:outline-none focus:border-yellow-400/50 transition-colors"
                      placeholder="John Smith"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Email</label>
                    <input
                      type="email"
                      className="w-full px-4 py-2 bg-black/30 border border-gray-800 rounded text-white placeholder-gray-500 focus:outline-none focus:border-yellow-400/50 transition-colors"
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Portfolio Size</label>
                    <select className="w-full px-4 py-2 bg-black/30 border border-gray-800 rounded text-white focus:outline-none focus:border-yellow-400/50 transition-colors">
                      <option>$10M - $50M</option>
                      <option>$50M - $100M</option>
                      <option>$100M - $500M</option>
                      <option>$500M+</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Intelligence Needs</label>
                    <textarea
                      rows={4}
                      className="w-full px-4 py-2 bg-black/30 border border-gray-800 rounded text-white placeholder-gray-500 focus:outline-none focus:border-yellow-400/50 transition-colors resize-none"
                      placeholder="Describe your requirements..."
                    />
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full px-4 py-3 bg-gradient-to-r from-yellow-400 to-yellow-600 text-black font-semibold rounded hover:shadow-lg hover:shadow-yellow-400/20 transition-all"
                  >
                    Submit Request
                  </motion.button>
                </form>
              </div>

              {/* Contact Information */}
              <div className="glassmorphism p-6 rounded-lg">
                <h3 className="text-xl font-bold text-white mb-4">Enterprise Contact</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="text-yellow-400 mt-1">📧</div>
                    <div>
                      <div className="text-sm text-gray-400">Email</div>
                      <div className="text-white">intelligence@atlas-neural.ai</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="text-yellow-400 mt-1">🌐</div>
                    <div>
                      <div className="text-sm text-gray-400">Global Operations</div>
                      <div className="text-white">24/7 Neural Network</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="text-yellow-400 mt-1">🔒</div>
                    <div>
                      <div className="text-sm text-gray-400">Security</div>
                      <div className="text-white">Enterprise-grade encryption</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* System Status */}
              <div className="glassmorphism p-6 rounded-lg">
                <h3 className="text-xl font-bold text-white mb-4">System Status</h3>
                <div className="space-y-3">
                  <StatusItem label="Neural Network" status="Operational" />
                  <StatusItem label="Market Intelligence" status="Operational" />
                  <StatusItem label="Data Processing" status="Operational" />
                  <StatusItem label="API Response" status="42ms avg" />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  );
}

function StatusItem({ label, status }: { label: string; status: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-gray-400">{label}</span>
      <div className="flex items-center space-x-2">
        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
        <span className="text-green-400 font-semibold">{status}</span>
      </div>
    </div>
  );
}
