"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";

const terminalLogs = [
  { time: "14:32:18", level: "INFO", message: "Neural Agent #3 completed market scan: 847 properties analyzed" },
  { time: "14:31:42", level: "SUCCESS", message: "Acquisition opportunity detected in Dubai Marina - Score: 96.8" },
  { time: "14:30:15", level: "INFO", message: "Portfolio optimization cycle initiated" },
  { time: "14:29:33", level: "WARNING", message: "Market volatility increased in London - Risk level: 12.4%" },
  { time: "14:28:07", level: "SUCCESS", message: "Yield forecast updated - Confidence: 98.2%" },
  { time: "14:27:51", level: "INFO", message: "Neural thread #47 synchronized with global network" },
  { time: "14:26:29", level: "INFO", message: "Capital flow detected: $847.3M in Miami luxury segment" },
  { time: "14:25:14", level: "SUCCESS", message: "Risk assessment completed for 142 active assets" },
];

const activeAgents = [
  { id: 1, name: "Acquisition Agent", status: "Processing", threads: 24, uptime: "99.8%" },
  { id: 2, name: "Market Intelligence", status: "Active", threads: 31, uptime: "99.9%" },
  { id: 3, name: "Yield Optimizer", status: "Active", threads: 18, uptime: "100%" },
  { id: 4, name: "Negotiation Agent", status: "Standby", threads: 8, uptime: "99.7%" },
  { id: 5, name: "Portfolio Strategy", status: "Processing", threads: 22, uptime: "99.9%" },
  { id: 6, name: "Risk Analysis", status: "Active", threads: 27, uptime: "100%" },
];

export default function CommandCenterPage() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [logIndex, setLogIndex] = useState(0);
  const [displayedLogs, setDisplayedLogs] = useState(terminalLogs.slice(0, 8));

  useEffect(() => {
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    const logInterval = setInterval(() => {
      setLogIndex((prev) => (prev + 1) % terminalLogs.length);
      setDisplayedLogs((prev) => {
        const newLogs = [...prev];
        newLogs.shift();
        newLogs.push(terminalLogs[(logIndex + 8) % terminalLogs.length]);
        return newLogs;
      });
    }, 5000);

    return () => {
      clearInterval(timeInterval);
      clearInterval(logInterval);
    };
  }, [logIndex]);

  return (
    <main className="min-h-screen">
      <Navbar />

      <div className="pt-20 pb-12 px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="inline-flex items-center space-x-2 px-4 py-2 glassmorphism-light rounded-full mb-4">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-sm text-gray-300 font-medium uppercase tracking-wider">
                    Systems Operational
                  </span>
                </div>
                <h1 className="text-4xl md:text-5xl font-bold mb-2">
                  <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                    Command Center
                  </span>
                </h1>
                <p className="text-xl text-gray-400">
                  Real-time neural network operations dashboard
                </p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-mono font-bold text-yellow-400">
                  {currentTime.toLocaleTimeString()}
                </div>
                <div className="text-sm text-gray-400 uppercase tracking-wider">
                  {currentTime.toLocaleDateString()}
                </div>
              </div>
            </div>
          </motion.div>

          {/* System Status Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <StatusCard title="System Uptime" value="99.9%" status="optimal" />
            <StatusCard title="Active Threads" value="130" status="optimal" />
            <StatusCard title="Queue Length" value="23" status="normal" />
            <StatusCard title="Response Time" value="42ms" status="optimal" />
          </div>

          {/* Main Dashboard Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Terminal Logs */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="lg:col-span-2 glassmorphism rounded-lg overflow-hidden"
            >
              <div className="p-6 border-b border-gray-800 flex items-center justify-between">
                <h2 className="text-xl font-bold text-white">Live System Logs</h2>
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-xs text-green-400 uppercase font-semibold">Streaming</span>
                </div>
              </div>
              <div className="p-6 bg-black/40 font-mono text-xs space-y-2 h-96 overflow-auto">
                {displayedLogs.map((log, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex space-x-3 text-gray-400"
                  >
                    <span className="text-gray-600">[{log.time}]</span>
                    <span className={
                      log.level === "SUCCESS" ? "text-green-400" :
                      log.level === "WARNING" ? "text-yellow-400" :
                      "text-blue-400"
                    }>
                      {log.level}
                    </span>
                    <span>{log.message}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Active Agents */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="glassmorphism rounded-lg overflow-hidden"
            >
              <div className="p-6 border-b border-gray-800">
                <h2 className="text-xl font-bold text-white">Active Agents</h2>
              </div>
              <div className="p-6 space-y-4">
                {activeAgents.map((agent) => (
                  <div
                    key={agent.id}
                    className="bg-black/30 border border-gray-800 rounded-lg p-4 hover:border-yellow-400/30 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold text-white">{agent.name}</span>
                      <span className={`text-xs px-2 py-1 rounded ${
                        agent.status === "Active" ? "bg-green-400/10 text-green-400" :
                        agent.status === "Processing" ? "bg-blue-400/10 text-blue-400" :
                        "bg-gray-400/10 text-gray-400"
                      }`}>
                        {agent.status}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Threads: {agent.threads}</span>
                      <span>Uptime: {agent.uptime}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Acquisition Queue */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="mt-6 glassmorphism rounded-lg overflow-hidden"
          >
            <div className="p-6 border-b border-gray-800">
              <h2 className="text-xl font-bold text-white">Acquisition Queue</h2>
            </div>
            <div className="p-6">
              <div className="space-y-3">
                <QueueItem
                  property="Dubai Marina Penthouse"
                  score={96.8}
                  status="Analyzing"
                  priority="High"
                />
                <QueueItem
                  property="Miami Beach Tower"
                  score={94.2}
                  status="Risk Assessment"
                  priority="High"
                />
                <QueueItem
                  property="London Mayfair Estate"
                  score={91.5}
                  status="Market Research"
                  priority="Medium"
                />
                <QueueItem
                  property="Tokyo Shibuya Suite"
                  score={88.3}
                  status="Queued"
                  priority="Medium"
                />
                <QueueItem
                  property="Singapore Marina Bay"
                  score={92.7}
                  status="Monitoring"
                  priority="Low"
                />
              </div>
            </div>
          </motion.div>

          {/* Performance Metrics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            <div className="glassmorphism p-6 rounded-lg">
              <h3 className="text-lg font-bold text-white mb-4">Processing Timeline</h3>
              <div className="space-y-3">
                <TimelineItem time="2m ago" event="Portfolio optimization completed" />
                <TimelineItem time="8m ago" event="Market scan: 847 properties" />
                <TimelineItem time="15m ago" event="Risk assessment updated" />
                <TimelineItem time="23m ago" event="New acquisition detected" />
                <TimelineItem time="31m ago" event="Yield forecast generated" />
              </div>
            </div>

            <div className="glassmorphism p-6 rounded-lg">
              <h3 className="text-lg font-bold text-white mb-4">Network Synchronization</h3>
              <div className="space-y-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-3">
                    <div className="flex-shrink-0 w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-gray-400">Neural Thread #{i + 42}</span>
                        <span className="text-xs text-green-400">Synced</span>
                      </div>
                      <div className="h-1 bg-gray-800 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-yellow-400 to-green-400"
                          initial={{ width: 0 }}
                          animate={{ width: "100%" }}
                          transition={{ duration: 1, delay: i * 0.1 }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <Footer />
    </main>
  );
}

function StatusCard({
  title,
  value,
  status
}: {
  title: string;
  value: string;
  status: "optimal" | "normal" | "warning";
}) {
  const statusColors = {
    optimal: "text-green-400",
    normal: "text-blue-400",
    warning: "text-yellow-400",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="glassmorphism p-6 rounded-lg"
    >
      <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">{title}</div>
      <div className={`text-3xl font-bold ${statusColors[status]} mb-1`}>{value}</div>
      <div className="text-xs text-gray-600 uppercase">{status}</div>
    </motion.div>
  );
}

function QueueItem({
  property,
  score,
  status,
  priority
}: {
  property: string;
  score: number;
  status: string;
  priority: string;
}) {
  return (
    <div className="flex items-center justify-between p-4 bg-black/30 border border-gray-800 rounded-lg hover:border-yellow-400/30 transition-colors">
      <div className="flex items-center space-x-4">
        <div className={`px-2 py-1 text-xs rounded ${
          priority === "High" ? "bg-red-400/10 text-red-400" :
          priority === "Medium" ? "bg-yellow-400/10 text-yellow-400" :
          "bg-gray-400/10 text-gray-400"
        }`}>
          {priority}
        </div>
        <span className="text-sm text-white">{property}</span>
      </div>
      <div className="flex items-center space-x-4">
        <span className="text-xs text-gray-400">{status}</span>
        <span className="text-sm font-bold text-yellow-400">{score}</span>
      </div>
    </div>
  );
}

function TimelineItem({ time, event }: { time: string; event: string }) {
  return (
    <div className="flex items-start space-x-3">
      <div className="flex-shrink-0 w-2 h-2 bg-yellow-400 rounded-full mt-1.5" />
      <div>
        <div className="text-xs text-gray-500">{time}</div>
        <div className="text-sm text-gray-300">{event}</div>
      </div>
    </div>
  );
}
