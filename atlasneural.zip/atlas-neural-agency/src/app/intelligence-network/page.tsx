"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import Globe3D from "@/components/globe-3d";

const cityData = {
  "New York": {
    properties: [
      { name: "Manhattan Penthouse", price: "$12.5M", yield: "6.8%", score: 94 },
      { name: "Brooklyn Luxury Loft", price: "$8.2M", yield: "7.2%", score: 91 },
    ],
    marketAnalysis: "Strong institutional demand, stable appreciation",
    projectedYield: "6.8%",
    riskLevel: "Medium",
    confidence: 94.2,
  },
  "Dubai": {
    properties: [
      { name: "Burj Khalifa Penthouse", price: "$25M", yield: "8.4%", score: 97 },
      { name: "Palm Jumeirah Villa", price: "$18M", yield: "7.9%", score: 95 },
    ],
    marketAnalysis: "Explosive growth, high-net-worth migration",
    projectedYield: "8.4%",
    riskLevel: "Low",
    confidence: 96.8,
  },
  "London": {
    properties: [
      { name: "Mayfair Estate", price: "£15M", yield: "5.9%", score: 92 },
      { name: "Knightsbridge Residence", price: "£22M", yield: "5.4%", score: 90 },
    ],
    marketAnalysis: "Stable luxury market, historic appreciation",
    projectedYield: "5.9%",
    riskLevel: "Low",
    confidence: 91.5,
  },
  "Tokyo": {
    properties: [
      { name: "Shibuya Tower Suite", price: "¥2.8B", yield: "4.8%", score: 88 },
      { name: "Roppongi Luxury Flat", price: "¥2.1B", yield: "5.1%", score: 86 },
    ],
    marketAnalysis: "Emerging luxury segment, Olympics impact",
    projectedYield: "4.8%",
    riskLevel: "Medium",
    confidence: 88.3,
  },
  "Singapore": {
    properties: [
      { name: "Marina Bay Penthouse", price: "S$38M", yield: "6.2%", score: 93 },
      { name: "Sentosa Cove Villa", price: "S$45M", yield: "5.8%", score: 92 },
    ],
    marketAnalysis: "Strong Asian wealth hub, limited supply",
    projectedYield: "6.2%",
    riskLevel: "Low",
    confidence: 92.7,
  },
  "Miami": {
    properties: [
      { name: "Miami Beach Penthouse", price: "$19M", yield: "7.4%", score: 96 },
      { name: "Brickell Tower Suite", price: "$6.8M", yield: "8.1%", score: 94 },
    ],
    marketAnalysis: "Tech migration driving demand, tax benefits",
    projectedYield: "7.4%",
    riskLevel: "Low",
    confidence: 96.1,
  },
  "Los Angeles": {
    properties: [
      { name: "Beverly Hills Mansion", price: "$45M", yield: "5.2%", score: 89 },
      { name: "Malibu Oceanfront", price: "$32M", yield: "4.9%", score: 87 },
    ],
    marketAnalysis: "Celebrity and tech elite market",
    projectedYield: "5.2%",
    riskLevel: "Medium",
    confidence: 88.7,
  },
  "Toronto": {
    properties: [
      { name: "Yorkville Penthouse", price: "C$12M", yield: "6.5%", score: 90 },
      { name: "Waterfront Condo", price: "C$8.5M", yield: "7.1%", score: 88 },
    ],
    marketAnalysis: "Strong fundamentals, immigration growth",
    projectedYield: "6.5%",
    riskLevel: "Low",
    confidence: 89.8,
  },
  "Paris": {
    properties: [
      { name: "Champs-Élysées Apartment", price: "€18M", yield: "4.6%", score: 87 },
      { name: "Le Marais Historic Estate", price: "€25M", yield: "4.2%", score: 85 },
    ],
    marketAnalysis: "Timeless luxury, heritage value",
    projectedYield: "4.6%",
    riskLevel: "Low",
    confidence: 86.9,
  },
  "Istanbul": {
    properties: [
      { name: "Bosphorus Waterfront", price: "₺285M", yield: "9.2%", score: 91 },
      { name: "Nisantasi Luxury Flat", price: "₺180M", yield: "8.7%", score: 89 },
    ],
    marketAnalysis: "Emerging market, high yields",
    projectedYield: "9.2%",
    riskLevel: "Medium-High",
    confidence: 90.3,
  },
};

export default function IntelligenceNetworkPage() {
  const [selectedCity, setSelectedCity] = useState<string | null>(null);

  return (
    <main className="min-h-screen">
      <Navbar />

      <div className="pt-20 pb-12 px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center space-x-2 px-4 py-2 glassmorphism-light rounded-full mb-6">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-sm text-gray-300 font-medium uppercase tracking-wider">
                Global Intelligence Network
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                Real-Time Market Intelligence
              </span>
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Monitor global acquisition opportunities across 10 major markets with autonomous neural analysis
            </p>
          </motion.div>

          {/* Globe and Info Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* 3D Globe */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="lg:col-span-2 glassmorphism rounded-lg overflow-hidden"
              style={{ height: "600px" }}
            >
              <div className="p-6 border-b border-gray-800">
                <h2 className="text-xl font-bold text-white">Global Network Map</h2>
                <p className="text-sm text-gray-400 mt-1">
                  Click cities to view intelligence data
                </p>
              </div>
              <div className="h-[520px]">
                <Globe3D onCityClick={setSelectedCity} />
              </div>
            </motion.div>

            {/* City Intelligence Panel */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              {/* Network Status */}
              <div className="glassmorphism p-6 rounded-lg">
                <h3 className="text-lg font-bold text-white mb-4">Network Status</h3>
                <div className="space-y-3">
                  <StatusItem label="Active Nodes" value="10" status="online" />
                  <StatusItem label="Markets Monitored" value="47" status="online" />
                  <StatusItem label="Live Properties" value="14,281" status="online" />
                  <StatusItem label="Data Streams" value="Real-Time" status="online" />
                </div>
              </div>

              {/* Top Markets */}
              <div className="glassmorphism p-6 rounded-lg">
                <h3 className="text-lg font-bold text-white mb-4">Top Markets</h3>
                <div className="space-y-3">
                  <MarketItem city="Dubai" score={96.8} trend="up" />
                  <MarketItem city="Miami" score={96.1} trend="up" />
                  <MarketItem city="New York" score={94.2} trend="stable" />
                  <MarketItem city="Singapore" score={92.7} trend="up" />
                  <MarketItem city="London" score={91.5} trend="stable" />
                </div>
              </div>
            </motion.div>
          </div>

          {/* City Details */}
          {selectedCity && cityData[selectedCity as keyof typeof cityData] && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 glassmorphism p-8 rounded-lg"
            >
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-3xl font-bold text-white mb-2">{selectedCity}</h2>
                  <p className="text-gray-400">
                    {cityData[selectedCity as keyof typeof cityData].marketAnalysis}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedCity(null)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <MetricCard
                  label="Projected Yield"
                  value={cityData[selectedCity as keyof typeof cityData].projectedYield}
                />
                <MetricCard
                  label="Risk Level"
                  value={cityData[selectedCity as keyof typeof cityData].riskLevel}
                />
                <MetricCard
                  label="AI Confidence"
                  value={`${cityData[selectedCity as keyof typeof cityData].confidence}%`}
                />
                <MetricCard
                  label="Status"
                  value="Monitoring"
                />
              </div>

              <h3 className="text-xl font-bold text-white mb-4">Featured Properties</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {cityData[selectedCity as keyof typeof cityData].properties.map((property) => (
                  <div
                    key={property.name}
                    className="bg-black/30 border border-gray-800 rounded-lg p-6 hover:border-yellow-400/30 transition-colors"
                  >
                    <h4 className="text-lg font-bold text-white mb-2">{property.name}</h4>
                    <div className="grid grid-cols-3 gap-3 text-sm">
                      <div>
                        <div className="text-gray-500 mb-1">Price</div>
                        <div className="text-white font-semibold">{property.price}</div>
                      </div>
                      <div>
                        <div className="text-gray-500 mb-1">Yield</div>
                        <div className="text-green-400 font-semibold">{property.yield}</div>
                      </div>
                      <div>
                        <div className="text-gray-500 mb-1">AI Score</div>
                        <div className="text-yellow-400 font-semibold">{property.score}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>

      <Footer />
    </main>
  );
}

function StatusItem({ label, value, status }: { label: string; value: string; status: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-gray-400">{label}</span>
      <div className="flex items-center space-x-2">
        <span className="text-white font-semibold">{value}</span>
        <div className={`w-2 h-2 rounded-full ${
          status === "online" ? "bg-green-400 animate-pulse" : "bg-gray-400"
        }`} />
      </div>
    </div>
  );
}

function MarketItem({ city, score, trend }: { city: string; score: number; trend: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <div className="flex items-center space-x-2">
        <div className={`w-1.5 h-1.5 rounded-full ${
          trend === "up" ? "bg-green-400" :
          trend === "down" ? "bg-red-400" : "bg-gray-400"
        }`} />
        <span className="text-gray-300">{city}</span>
      </div>
      <span className="text-yellow-400 font-semibold">{score}</span>
    </div>
  );
}

function MetricCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-black/30 border border-gray-800 rounded-lg p-4">
      <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">{label}</div>
      <div className="text-xl font-bold text-white">{value}</div>
    </div>
  );
}
