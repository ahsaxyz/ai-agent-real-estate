"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Link from "next/link";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Platform", href: "/" },
    { name: "Intelligence", href: "/intelligence-network" },
    { name: "Command Center", href: "/command-center" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <motion.nav
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50"
    >
      <div
        className={`flex items-center justify-between px-6 py-3 transition-all duration-300 border border-white/10 ${
          scrolled
            ? "bg-black/80 backdrop-blur-xl"
            : "bg-black/60 backdrop-blur-md"
        }`}
        style={{ minWidth: "900px" }}
      >
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-3">
          <div className="relative w-8 h-8">
            <div className="absolute inset-0 bg-gradient-to-br from-yellow-400 to-yellow-600 opacity-90" />
            <div className="absolute inset-0.5 bg-black flex items-center justify-center">
              <span className="text-yellow-400 font-bold text-sm">A</span>
            </div>
          </div>
          <span className="text-sm font-semibold tracking-wider text-white uppercase">
            ATLAS
          </span>
        </Link>

        {/* Navigation Links */}
        <div className="flex items-center space-x-8">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="text-sm text-gray-400 hover:text-white transition-colors tracking-wide"
            >
              {item.name}
            </Link>
          ))}
        </div>

        {/* CTA Button */}
        <Link
          href="/contact"
          className="px-5 py-2 bg-white text-black text-sm font-medium hover:bg-gray-100 transition-colors"
        >
          Get Started
        </Link>
      </div>
    </motion.nav>
  );
}
