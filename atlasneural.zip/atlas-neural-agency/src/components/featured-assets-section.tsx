"use client";

import { motion } from "framer-motion";

const properties = [
  {
    title: "Burj Khalifa Penthouse",
    location: "Dubai, UAE",
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&q=80",
    aiScore: 96.8,
    yield: 8.4,
    risk: "Low",
    appreciation: 12.3,
    confidence: 97.2,
    volatility: 4.2,
    tags: ["Ultra-Luxury", "High-Growth", "Prime Location"],
  },
  {
    title: "Manhattan Luxury Tower",
    location: "New York, USA",
    image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&q=80",
    aiScore: 94.2,
    yield: 6.8,
    risk: "Medium",
    appreciation: 9.7,
    confidence: 94.5,
    volatility: 6.8,
    tags: ["Premium", "Established Market", "High Demand"],
  },
  {
    title: "Mayfair Estate",
    location: "London, UK",
    image: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&q=80",
    aiScore: 91.5,
    yield: 5.9,
    risk: "Low",
    appreciation: 7.4,
    confidence: 96.1,
    volatility: 3.6,
    tags: ["Historical", "Stable Growth", "Elite District"],
  },
];

export default function FeaturedAssetsSection() {
  return (
    <section id="assets" className="relative py-24 px-6 lg:px-8 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 atlas-grid opacity-20" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center space-x-2 px-4 py-2 glassmorphism-light rounded-full mb-6">
            <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />
            <span className="text-sm text-gray-300 font-medium uppercase tracking-wider">
              AI-Scored Opportunities
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              Featured Intelligence Assets
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Premium acquisition opportunities analyzed and scored by our autonomous neural network
          </p>
        </motion.div>

        {/* Property Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {properties.map((property, index) => (
            <PropertyCard key={property.title} property={property} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

function PropertyCard({ property, index }: { property: typeof properties[0]; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -10 }}
      className="glassmorphism rounded-lg overflow-hidden group"
    >
      {/* Property Image */}
      <div className="relative h-64 overflow-hidden">
        <img
          src={property.image}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />

        {/* AI Score Badge */}
        <div className="absolute top-4 right-4 px-4 py-2 glassmorphism rounded-lg">
          <div className="text-xs text-gray-400 mb-1">AI Score</div>
          <div className="text-2xl font-bold text-yellow-400">{property.aiScore}</div>
        </div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
      </div>

      {/* Property Info */}
      <div className="p-6">
        <h3 className="text-xl font-bold text-white mb-1 group-hover:text-yellow-400 transition-colors">
          {property.title}
        </h3>
        <p className="text-sm text-gray-400 mb-4">{property.location}</p>

        {/* Intelligence Metrics */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <MetricItem label="Projected Yield" value={`${property.yield}%`} positive />
          <MetricItem label="Risk Level" value={property.risk} />
          <MetricItem label="Appreciation" value={`+${property.appreciation}%`} positive />
          <MetricItem label="Confidence" value={`${property.confidence}%`} />
        </div>

        {/* Additional Metrics */}
        <div className="mb-4 p-3 bg-black/30 border border-gray-800 rounded">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="text-gray-500 uppercase tracking-wider">Market Volatility</span>
            <span className="text-white font-semibold">{property.volatility}%</span>
          </div>
          <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-green-400 to-yellow-400"
              style={{ width: `${100 - property.volatility * 10}%` }}
            />
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-4">
          {property.tags.map((tag) => (
            <span
              key={tag}
              className="px-2 py-1 text-xs bg-yellow-400/10 border border-yellow-400/30 text-yellow-400 rounded"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Action Button */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full px-4 py-3 bg-gradient-to-r from-yellow-400 to-yellow-600 text-black font-semibold text-sm rounded hover:shadow-lg hover:shadow-yellow-400/20 transition-all"
        >
          View Intelligence Report
        </motion.button>
      </div>
    </motion.div>
  );
}

function MetricItem({
  label,
  value,
  positive
}: {
  label: string;
  value: string;
  positive?: boolean;
}) {
  return (
    <div className="p-2 bg-black/30 border border-gray-800 rounded">
      <div className="text-xs text-gray-500 uppercase tracking-wider mb-1">{label}</div>
      <div className={`text-sm font-bold ${
        positive ? "text-green-400" : "text-white"
      }`}>
        {value}
      </div>
    </div>
  );
}
