"use client";

import { motion } from "framer-motion";

const stats = [
  {
    number: "$2.8B+",
    label: "Assets Under Analysis",
  },
  {
    number: "50+",
    label: "Global Markets Monitored",
  },
  {
    number: "98.2%",
    label: "Forecast Accuracy",
  },
  {
    number: "24/7",
    label: "Autonomous Operation",
  },
];

export default function StatsSection() {
  return (
    <section className="relative py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="border-l-2 border-black pl-6"
            >
              <div className="text-6xl font-bold text-black mb-3">
                {stat.number}
              </div>
              <div className="text-sm text-gray-600 uppercase tracking-wider">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
