"use client";

import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export default function IntelligenceDashboardSection() {
  const [marketData, setMarketData] = useState({
    capitalFlow: 847.3,
    acquisitionScore: 94.2,
    riskLevel: 12.4,
    portfolioValue: 2.8,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMarketData({
        capitalFlow: 847.3 + Math.random() * 10,
        acquisitionScore: 94.2 + Math.random() * 2,
        riskLevel: 12.4 - Math.random() * 2,
        portfolioValue: 2.8 + Math.random() * 0.1,
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative py-24 px-6 lg:px-8 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-yellow-500/5 to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center space-x-2 px-4 py-2 glassmorphism-light rounded-full mb-6">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
            <span className="text-sm text-gray-300 font-medium uppercase tracking-wider">
              Real-Time Intelligence
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              Command Dashboard
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Enterprise-grade intelligence platform for real-time market analysis and portfolio optimization
          </p>
        </motion.div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Market Intelligence Map */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glassmorphism p-6 rounded-lg"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">Market Intelligence Map</h3>
              <div className="px-3 py-1 bg-green-400/10 border border-green-400/30 rounded-full">
                <span className="text-xs text-green-400 font-semibold uppercase">Live</span>
              </div>
            </div>

            <div className="relative h-64 bg-black/40 rounded-lg overflow-hidden border border-gray-800">
              {/* Heatmap Grid */}
              <div className="absolute inset-0 grid grid-cols-8 grid-rows-6 gap-1 p-2">
                {[...Array(48)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="rounded"
                    animate={{
                      backgroundColor: [
                        `rgba(212, 175, 55, ${Math.random() * 0.5})`,
                        `rgba(212, 175, 55, ${Math.random() * 0.5})`,
                      ],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: Math.random(),
                    }}
                  />
                ))}
              </div>

              {/* Overlay Labels */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-4xl font-bold text-yellow-400 mb-1">
                    {marketData.capitalFlow.toFixed(1)}M
                  </div>
                  <div className="text-xs text-gray-400 uppercase tracking-wider">
                    Capital Flow Detected
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Acquisition Scoring */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glassmorphism p-6 rounded-lg"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-white">Acquisition Scoring</h3>
              <div className="px-3 py-1 bg-blue-400/10 border border-blue-400/30 rounded-full">
                <span className="text-xs text-blue-400 font-semibold uppercase">Updated 2m ago</span>
              </div>
            </div>

            <div className="space-y-4">
              {[
                { location: "Miami Beach, FL", score: 96.8, trend: "up" },
                { location: "Dubai Marina, UAE", score: 94.2, trend: "up" },
                { location: "Mayfair, London", score: 91.5, trend: "stable" },
                { location: "Shibuya, Tokyo", score: 88.3, trend: "down" },
                { location: "SoHo, New York", score: 86.7, trend: "up" },
              ].map((item, i) => (
                <motion.div
                  key={item.location}
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex items-center justify-between p-3 bg-black/30 rounded border border-gray-800 hover:border-yellow-400/30 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-2 h-2 rounded-full ${
                      item.trend === "up" ? "bg-green-400" :
                      item.trend === "down" ? "bg-red-400" : "bg-gray-400"
                    } animate-pulse`} />
                    <span className="text-sm text-gray-300">{item.location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-yellow-400">{item.score}</span>
                    <div className="w-16 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-yellow-400 to-yellow-600"
                        style={{ width: `${item.score}%` }}
                      />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Bottom Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <StatCard
            title="Capital Flow"
            value={`$${marketData.capitalFlow.toFixed(1)}M`}
            change="+12.4%"
            trend="up"
            delay={0}
          />
          <StatCard
            title="Acquisition Score"
            value={marketData.acquisitionScore.toFixed(1)}
            change="+2.1"
            trend="up"
            delay={0.1}
          />
          <StatCard
            title="Risk Level"
            value={`${marketData.riskLevel.toFixed(1)}%`}
            change="-1.8%"
            trend="down"
            delay={0.2}
          />
          <StatCard
            title="Portfolio Value"
            value={`$${marketData.portfolioValue.toFixed(1)}B`}
            change="+5.3%"
            trend="up"
            delay={0.3}
          />
        </div>

        {/* Activity Feed */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-6 glassmorphism p-6 rounded-lg"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-white">Live Activity Stream</h3>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-xs text-gray-400">Streaming</span>
            </div>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <ActivityItem
              time="00:42:18"
              message="Neural Agent detected high-growth acquisition zone in Dubai Marina"
              type="success"
            />
            <ActivityItem
              time="00:41:03"
              message="Market scan completed: 847 properties analyzed"
              type="info"
            />
            <ActivityItem
              time="00:39:27"
              message="Portfolio optimization updated for maximum yield"
              type="success"
            />
            <ActivityItem
              time="00:38:14"
              message="Risk assessment: Miami market volatility decreased 2.4%"
              type="warning"
            />
            <ActivityItem
              time="00:36:55"
              message="Yield forecast confidence increased to 98.2%"
              type="success"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function StatCard({
  title,
  value,
  change,
  trend,
  delay
}: {
  title: string;
  value: string;
  change: string;
  trend: "up" | "down";
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className="glassmorphism p-6 rounded-lg hover:border-yellow-400/30 transition-colors"
    >
      <div className="text-xs text-gray-500 uppercase tracking-wider mb-2">{title}</div>
      <div className="text-2xl font-bold text-white mb-2">{value}</div>
      <div className={`text-sm font-semibold ${
        trend === "up" ? "text-green-400" : "text-red-400"
      }`}>
        {change}
      </div>
    </motion.div>
  );
}

function ActivityItem({
  time,
  message,
  type
}: {
  time: string;
  message: string;
  type: "success" | "info" | "warning";
}) {
  const colors = {
    success: "text-green-400",
    info: "text-blue-400",
    warning: "text-yellow-400",
  };

  return (
    <div className="flex items-start space-x-3 text-gray-400">
      <span className="text-gray-600">[{time}]</span>
      <span className={colors[type]}>→</span>
      <span>{message}</span>
    </div>
  );
}
