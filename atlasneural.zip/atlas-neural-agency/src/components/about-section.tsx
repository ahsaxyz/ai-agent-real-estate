"use client";

import { motion } from "framer-motion";

export default function AboutSection() {
  return (
    <section className="relative py-24 px-6 lg:px-8 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-black via-yellow-500/5 to-black" />
      <div className="absolute inset-0 atlas-grid opacity-20" />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center space-x-2 px-4 py-2 glassmorphism-light rounded-full mb-8">
            <span className="text-sm text-gray-300 font-medium uppercase tracking-wider">
              About Atlas
            </span>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold mb-8">
            <span className="bg-gradient-to-r from-white via-gray-200 to-gray-400 bg-clip-text text-transparent">
              Autonomous Neural Infrastructure
            </span>
          </h2>

          <div className="space-y-6 text-lg text-gray-400 leading-relaxed">
            <p>
              Atlas Neural Agency is an experimental autonomous real estate intelligence platform
              focused on predictive acquisition, AI-driven market analysis, autonomous deal sourcing,
              and portfolio optimization.
            </p>

            <p>
              Our neural network architecture combines advanced machine learning with real-time market data
              to deliver institutional-grade intelligence workflows that operate 24/7 without human intervention.
            </p>

            <p>
              Trusted by governments and billion-dollar institutions, Atlas represents the future of
              real estate intelligence—where autonomous agents make data-driven decisions at the speed of markets.
            </p>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            <div className="glassmorphism p-6 rounded-lg">
              <div className="text-4xl font-bold text-yellow-400 mb-2">24/7</div>
              <div className="text-sm text-gray-400">Autonomous Operation</div>
            </div>
            <div className="glassmorphism p-6 rounded-lg">
              <div className="text-4xl font-bold text-yellow-400 mb-2">98%+</div>
              <div className="text-sm text-gray-400">Prediction Accuracy</div>
            </div>
            <div className="glassmorphism p-6 rounded-lg">
              <div className="text-4xl font-bold text-yellow-400 mb-2">$2.8B+</div>
              <div className="text-sm text-gray-400">Assets Under Analysis</div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
