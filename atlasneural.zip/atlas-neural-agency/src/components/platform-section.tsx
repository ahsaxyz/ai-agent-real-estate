"use client";

import { motion } from "framer-motion";
import { useState } from "react";

const categories = [
  "Acquisition",
  "Market Intelligence",
  "Global Assets",
  "Risk Modeling",
  "Portfolio OS",
  "Neural Agents",
];

const features = [
  {
    title: "The Real Estate OS for Autonomous Acquisition",
    description: "Deploy neural agents to scan global markets, evaluate opportunities, and execute acquisitions at institutional scale",
    category: "Platform",
  },
  {
    title: "Global Intelligence Network for Property Markets",
    description: "Real-time market analysis across 50+ cities with predictive modeling and risk assessment",
    category: "Intelligence",
  },
  {
    title: "Neural Agents for Deal Flow and Portfolio Strategy",
    description: "Autonomous systems that optimize portfolio allocation, identify alpha, and manage risk 24/7",
    category: "Automation",
  },
];

export default function PlatformSection() {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <section className="relative bg-gray-50 py-24">
      <div className="max-w-7xl mx-auto px-6">
        {/* Category Tabs */}
        <div className="flex items-center justify-center space-x-8 mb-16 border-b border-gray-200">
          {categories.map((category, index) => (
            <button
              key={category}
              onClick={() => setActiveTab(index)}
              className={`pb-4 text-sm font-medium tracking-wide transition-colors relative ${
                activeTab === index
                  ? "text-black"
                  : "text-gray-400 hover:text-gray-600"
              }`}
            >
              {category}
              {activeTab === index && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute bottom-0 left-0 right-0 h-[2px] bg-black"
                />
              )}
            </button>
          ))}
        </div>

        {/* Feature Cards */}
        <div className="space-y-6">
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

function FeatureCard({ feature, index }: { feature: typeof features[0]; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group relative bg-zinc-900 border border-zinc-800 overflow-hidden hover:border-zinc-700 transition-all"
    >
      <div className="grid grid-cols-1 md:grid-cols-2">
        {/* Content Side */}
        <div className="p-12 flex flex-col justify-center">
          <div className="text-xs text-gray-500 uppercase tracking-widest mb-4">
            {feature.category}
          </div>
          <h3 className="text-3xl font-bold text-white mb-4 leading-tight">
            {feature.title}
          </h3>
          <p className="text-gray-400 text-lg mb-6 leading-relaxed">
            {feature.description}
          </p>
          <div className="flex items-center space-x-2 text-white group-hover:text-yellow-400 transition-colors">
            <span className="text-sm font-medium">Learn More</span>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </div>
        </div>

        {/* Blueprint/Diagram Side */}
        <div className="relative bg-zinc-950 p-12 flex items-center justify-center border-l border-zinc-800">
          {/* Blueprint-style technical diagram */}
          <div className="w-full h-full relative">
            {/* Grid pattern */}
            <div
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: `
                  linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
                  linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)
                `,
                backgroundSize: '20px 20px'
              }}
            />

            {/* Technical diagram elements */}
            <div className="relative h-full flex items-center justify-center">
              <div className="grid grid-cols-3 gap-4 w-full">
                {[...Array(9)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.5 + i * 0.05 }}
                    className="border border-white/10 bg-white/5 aspect-square flex items-center justify-center"
                  >
                    <div className="w-2 h-2 bg-yellow-400/50" />
                  </motion.div>
                ))}
              </div>

              {/* Connection lines */}
              <svg className="absolute inset-0 w-full h-full" style={{ opacity: 0.2 }}>
                <line x1="33%" y1="50%" x2="50%" y2="50%" stroke="white" strokeWidth="1" />
                <line x1="50%" y1="50%" x2="67%" y2="50%" stroke="white" strokeWidth="1" />
                <line x1="50%" y1="33%" x2="50%" y2="67%" stroke="white" strokeWidth="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
