"use client";

import { motion } from "framer-motion";
import Link from "next/link";

export default function CTASection() {
  return (
    <section className="relative py-32 bg-zinc-900">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-5xl font-bold text-white mb-6">
            Deploy Autonomous Intelligence
          </h2>
          <p className="text-xl text-gray-400 mb-12 font-light">
            Request access to Atlas Neural Agency and transform your real estate operations with institutional-grade AI systems
          </p>
          <Link
            href="/contact"
            className="inline-block px-8 py-4 bg-white text-black text-sm font-medium hover:bg-gray-100 transition-colors"
          >
            Get Started
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
