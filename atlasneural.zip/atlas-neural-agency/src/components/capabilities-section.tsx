"use client";

import { motion } from "framer-motion";
import { useRef } from "react";

const capabilities = [
  {
    number: "01",
    title: "Autonomous Market Scanning",
    description: "Neural systems monitoring 50+ global markets in real-time, analyzing billions in transaction data",
    metrics: ["14,281 Properties Tracked", "$2.8B Volume Indexed", "24/7 Operation"],
  },
  {
    number: "02",
    title: "Predictive Acquisition Intelligence",
    description: "Machine learning models identifying high-potential opportunities before they reach market",
    metrics: ["98.2% Forecast Accuracy", "847 Markets Analyzed", "Real-Time Scoring"],
  },
  {
    number: "03",
    title: "Portfolio Optimization Engine",
    description: "Autonomous rebalancing and risk management across diversified real estate portfolios",
    metrics: ["12.4% Avg Return", "Advanced Risk Modeling", "Institutional Grade"],
  },
  {
    number: "04",
    title: "Global Intelligence Network",
    description: "Distributed neural agents operating across continents, synthesizing market intelligence",
    metrics: ["10 Global Hubs", "Multi-Currency Analysis", "Cross-Border Insights"],
  },
];

export default function CapabilitiesSection() {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <section className="relative py-24 bg-black overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 mb-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl"
        >
          <h2 className="text-5xl font-bold text-white mb-4">
            Enterprise Intelligence Capabilities
          </h2>
          <p className="text-xl text-gray-400 font-light">
            Institutional-grade systems trusted by governments and billion-dollar portfolios
          </p>
        </motion.div>
      </div>

      {/* Horizontal Scrolling Cards */}
      <div className="relative">
        <div
          ref={scrollRef}
          className="flex space-x-6 overflow-x-auto scrollbar-hide px-6 pb-8"
          style={{ scrollBehavior: "smooth" }}
        >
          {capabilities.map((capability, index) => (
            <CapabilityCard key={index} capability={capability} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CapabilityCard({
  capability,
  index
}: {
  capability: typeof capabilities[0];
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="flex-shrink-0 w-[500px] bg-zinc-900 border border-zinc-800 p-8 hover:border-zinc-700 transition-all group"
    >
      {/* Number */}
      <div className="text-6xl font-bold text-zinc-800 mb-6">
        {capability.number}
      </div>

      {/* Title */}
      <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-yellow-400 transition-colors">
        {capability.title}
      </h3>

      {/* Description */}
      <p className="text-gray-400 mb-8 leading-relaxed">
        {capability.description}
      </p>

      {/* Metrics */}
      <div className="space-y-3">
        {capability.metrics.map((metric, i) => (
          <div key={i} className="flex items-center space-x-3">
            <div className="w-1 h-1 bg-yellow-400" />
            <span className="text-sm text-gray-500">{metric}</span>
          </div>
        ))}
      </div>

      {/* Technical visualization */}
      <div className="mt-8 h-24 border-t border-zinc-800 pt-6">
        <div className="flex items-end justify-between h-full space-x-1">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ height: 0 }}
              whileInView={{ height: `${Math.random() * 100}%` }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 + i * 0.02 }}
              className="flex-1 bg-white/10"
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}
