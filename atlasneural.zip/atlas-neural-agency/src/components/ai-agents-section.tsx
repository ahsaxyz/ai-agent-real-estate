"use client";

import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const agents = [
  {
    name: "Acquisition Agent",
    description: "Identifies and evaluates high-potential acquisition targets",
    icon: "🎯",
    tasks: ["Scanning 847 markets", "Evaluating 23 opportunities", "Risk assessment active"],
  },
  {
    name: "Market Intelligence Agent",
    description: "Analyzes global real estate trends and economic indicators",
    icon: "🧠",
    tasks: ["Processing market data", "Trend analysis complete", "Forecast generation active"],
  },
  {
    name: "Yield Optimization Agent",
    description: "Maximizes portfolio returns through predictive analytics",
    icon: "📊",
    tasks: ["Optimizing 142 assets", "Yield projection updated", "Capital allocation active"],
  },
  {
    name: "Negotiation Agent",
    description: "Executes strategic negotiation workflows autonomously",
    icon: "🤝",
    tasks: ["3 negotiations active", "Deal structuring ongoing", "Counter-offers analyzed"],
  },
  {
    name: "Portfolio Strategy Agent",
    description: "Develops long-term portfolio strategies and diversification plans",
    icon: "🗺️",
    tasks: ["Strategy optimization", "Diversification analysis", "Rebalancing calculated"],
  },
  {
    name: "Risk Analysis Agent",
    description: "Monitors and mitigates portfolio risk in real time",
    icon: "🛡️",
    tasks: ["Risk scanning active", "Threat detection online", "Mitigation plans ready"],
  },
];

export default function AIAgentsSection() {
  return (
    <section id="agents" className="relative py-24 px-6 lg:px-8 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 atlas-grid opacity-20" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center space-x-2 px-4 py-2 glassmorphism-light rounded-full mb-6">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-sm text-gray-300 font-medium uppercase tracking-wider">
              Neural Network Active
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              Autonomous Agent Network
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Six specialized neural agents working 24/7 to optimize your real estate intelligence operations
          </p>
        </motion.div>

        {/* Agent Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent, index) => (
            <AgentCard key={agent.name} agent={agent} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

function AgentCard({ agent, index }: { agent: typeof agents[0]; index: number }) {
  const baseConfidence = 92 + index * 0.8;
  const baseThreads = 15 + index * 2;
  const [confidence, setConfidence] = useState(baseConfidence);
  const [threads, setThreads] = useState(baseThreads);
  const [currentTask, setCurrentTask] = useState(0);

  useEffect(() => {
    const confidenceInterval = setInterval(() => {
      setConfidence(92 + Math.random() * 7);
    }, 4000);

    const threadsInterval = setInterval(() => {
      setThreads(Math.floor(Math.random() * 20) + 10);
    }, 3000);

    const taskInterval = setInterval(() => {
      setCurrentTask((prev) => (prev + 1) % agent.tasks.length);
    }, 5000);

    return () => {
      clearInterval(confidenceInterval);
      clearInterval(threadsInterval);
      clearInterval(taskInterval);
    };
  }, [agent.tasks.length]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -5 }}
      className="glassmorphism p-6 rounded-lg group hover:border-yellow-400/30 transition-all"
    >
      {/* Agent Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="text-4xl">{agent.icon}</div>
        <div className="flex items-center space-x-2 px-3 py-1 bg-green-400/10 border border-green-400/30 rounded-full">
          <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
          <span className="text-xs text-green-400 font-semibold uppercase tracking-wider">
            Active
          </span>
        </div>
      </div>

      {/* Agent Name */}
      <h3 className="text-xl font-bold text-white mb-2 group-hover:text-yellow-400 transition-colors">
        {agent.name}
      </h3>

      {/* Description */}
      <p className="text-sm text-gray-400 mb-4">
        {agent.description}
      </p>

      {/* Confidence Meter */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-gray-500 uppercase tracking-wider">Confidence</span>
          <span className="text-sm font-bold text-yellow-400">{confidence.toFixed(1)}%</span>
        </div>
        <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-yellow-400 to-yellow-600"
            initial={{ width: 0 }}
            animate={{ width: `${confidence}%` }}
            transition={{ duration: 0.8 }}
          />
        </div>
      </div>

      {/* Neural Threads */}
      <div className="flex items-center justify-between mb-4 text-xs">
        <span className="text-gray-500 uppercase tracking-wider">Neural Threads</span>
        <span className="text-white font-mono font-semibold">{threads}</span>
      </div>

      {/* Live Task Feed */}
      <div className="bg-black/30 border border-gray-800 rounded p-3">
        <div className="flex items-center space-x-2 mb-2">
          <div className="w-1 h-1 bg-yellow-400 rounded-full animate-pulse" />
          <span className="text-xs text-gray-500 uppercase tracking-wider">Current Task</span>
        </div>
        <motion.p
          key={currentTask}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 10 }}
          className="text-xs text-gray-300 font-mono"
        >
          {agent.tasks[currentTask]}
        </motion.p>
      </div>

      {/* Mini Activity Graph */}
      <div className="mt-4 flex items-end justify-between h-12 space-x-1">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="flex-1 bg-yellow-400/20 rounded-t"
            animate={{
              height: `${Math.random() * 100}%`,
            }}
            transition={{
              duration: 1,
              repeat: Infinity,
              delay: i * 0.1,
            }}
          />
        ))}
      </div>
    </motion.div>
  );
}
