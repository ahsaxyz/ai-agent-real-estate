"use client";

import { motion } from "framer-motion";

const workflowSteps = [
  {
    title: "Market Scanning",
    description: "Continuous monitoring of global real estate markets",
    icon: "🔍",
  },
  {
    title: "Neural Analysis",
    description: "Deep learning models analyze patterns and trends",
    icon: "🧠",
  },
  {
    title: "Opportunity Detection",
    description: "AI identifies high-potential acquisition targets",
    icon: "🎯",
  },
  {
    title: "Risk Modeling",
    description: "Predictive analytics assess investment risks",
    icon: "📊",
  },
  {
    title: "Acquisition Intelligence",
    description: "Strategic recommendations for optimal deals",
    icon: "💼",
  },
  {
    title: "Portfolio Optimization",
    description: "Autonomous rebalancing for maximum returns",
    icon: "📈",
  },
];

export default function WorkflowSection() {
  return (
    <section className="relative py-24 px-6 lg:px-8 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 atlas-grid opacity-20" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black to-transparent" />

      <div className="relative z-10 max-w-5xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center space-x-2 px-4 py-2 glassmorphism-light rounded-full mb-6">
            <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" />
            <span className="text-sm text-gray-300 font-medium uppercase tracking-wider">
              Autonomous System
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              Intelligence Workflow
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            End-to-end autonomous pipeline from market detection to portfolio optimization
          </p>
        </motion.div>

        {/* Workflow Steps */}
        <div className="space-y-8">
          {workflowSteps.map((step, index) => (
            <div key={step.title}>
              {/* Step Card */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="relative"
              >
                <div className="flex items-start space-x-6">
                  {/* Icon Circle */}
                  <div className="relative flex-shrink-0">
                    <div className="w-20 h-20 glassmorphism rounded-full flex items-center justify-center text-3xl group-hover:border-yellow-400/50 transition-colors">
                      {step.icon}
                    </div>
                    <div className="absolute -inset-2 bg-yellow-400/10 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>

                  {/* Content */}
                  <div className="flex-1 glassmorphism p-6 rounded-lg hover:border-yellow-400/30 transition-all group">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-bold text-white group-hover:text-yellow-400 transition-colors">
                        {step.title}
                      </h3>
                      <div className="flex items-center space-x-2">
                        <div className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                        <span className="text-xs text-green-400 font-semibold uppercase">Active</span>
                      </div>
                    </div>
                    <p className="text-gray-400">{step.description}</p>

                    {/* Processing Bar */}
                    <div className="mt-4 h-1 bg-gray-800 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-yellow-400 to-yellow-600"
                        initial={{ width: "0%" }}
                        whileInView={{ width: "100%" }}
                        viewport={{ once: true }}
                        transition={{
                          duration: 2,
                          delay: index * 0.2,
                          ease: "easeInOut",
                        }}
                      />
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Connection Line with Particles */}
              {index < workflowSteps.length - 1 && (
                <div className="relative h-16 flex items-center justify-center">
                  <div className="w-0.5 h-full bg-gradient-to-b from-yellow-400/50 via-yellow-400/30 to-transparent" />

                  {/* Moving Particle */}
                  <motion.div
                    className="absolute w-2 h-2 bg-yellow-400 rounded-full"
                    animate={{
                      y: [0, 64],
                      opacity: [0, 1, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: index * 0.3,
                    }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Loop Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-12 text-center"
        >
          <div className="inline-flex items-center space-x-3 px-6 py-3 glassmorphism rounded-full">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="text-2xl"
            >
              ♻️
            </motion.div>
            <span className="text-sm text-gray-400">
              Continuous autonomous optimization cycle
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
