"use client";

import { motion, useScroll, useTransform } from "framer-motion";

export default function HeroSection() {
  const { scrollY } = useScroll();
  const globeY = useTransform(scrollY, [0, 500], [0, -50]);
  const globeOpacity = useTransform(scrollY, [0, 300], [1, 0.4]);

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-black">
      {/* Hidden Intelligence Infrastructure Background */}
      <motion.div
        className="absolute inset-0 flex items-center justify-center"
        style={{ y: globeY, opacity: globeOpacity }}
      >
        {/* Faint operational grid overlay - more visible */}
        <div className="absolute inset-0 opacity-[0.06]">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="smallGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.5"/>
              </pattern>
              <pattern id="grid" width="200" height="200" patternUnits="userSpaceOnUse">
                <rect width="200" height="200" fill="url(#smallGrid)"/>
                <path d="M 200 0 L 0 0 0 200" fill="none" stroke="rgba(255,255,255,0.6)" strokeWidth="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Low-opacity intelligence dashboard elements */}
        <div className="absolute inset-0 opacity-[0.08]">
          {/* Top left status panel */}
          <div className="absolute top-20 left-12 border border-white/20 px-4 py-2">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
              <span className="text-[10px] text-white/60 font-mono tracking-wider">SYSTEM ACTIVE</span>
            </div>
          </div>

          {/* Top right metrics */}
          <div className="absolute top-20 right-12 border border-white/20 px-4 py-2">
            <div className="text-[10px] text-white/60 font-mono">
              <div>MARKETS: 50+</div>
              <div className="text-[#D4AF37]">ACCURACY: 98.2%</div>
            </div>
          </div>

          {/* Bottom left coordinates */}
          <div className="absolute bottom-24 left-12 border border-white/20 px-4 py-2">
            <div className="text-[10px] text-white/60 font-mono">
              <div>LAT: 40.7128° N</div>
              <div>LON: 74.0060° W</div>
            </div>
          </div>

          {/* Bottom right timestamp */}
          <div className="absolute bottom-24 right-12 border border-white/20 px-4 py-2">
            <div className="text-[10px] text-white/60 font-mono">
              UTC+00:00
            </div>
          </div>

          {/* Scanning line indicator */}
          <motion.div
            className="absolute left-1/4 w-px h-12 bg-gradient-to-b from-transparent via-[#D4AF37]/30 to-transparent"
            animate={{ top: ["10%", "80%"] }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          />
        </div>

        {/* Central Intelligence Globe - more visible */}
        <motion.div
          className="absolute w-[110vh] h-[110vh]"
          animate={{
            rotateY: [0, 360],
          }}
          transition={{
            duration: 300,
            repeat: Infinity,
            ease: "linear",
          }}
          style={{
            transformStyle: "preserve-3d",
          }}
        >
          <svg
            viewBox="-500 -500 1000 1000"
            className="w-full h-full"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <radialGradient id="globeGradient">
                <stop offset="0%" stopColor="#1a1a1a" />
                <stop offset="70%" stopColor="#0f0f0f" />
                <stop offset="100%" stopColor="#050505" />
              </radialGradient>

              <radialGradient id="atmosphereGlow">
                <stop offset="60%" stopColor="transparent" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.03)" />
              </radialGradient>

              <linearGradient id="dataFlowGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.06)" />
                <stop offset="50%" stopColor="rgba(212,175,55,0.2)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.06)" />
              </linearGradient>

              <linearGradient id="topologyGradient">
                <stop offset="0%" stopColor="rgba(255,255,255,0.04)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.08)" />
              </linearGradient>

              <linearGradient id="neuralPathGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="rgba(212,175,55,0.0)" />
                <stop offset="50%" stopColor="rgba(212,175,55,0.25)" />
                <stop offset="100%" stopColor="rgba(212,175,55,0.0)" />
              </linearGradient>
            </defs>

            {/* Globe sphere - visible dark gray base */}
            <circle cx="0" cy="0" r="400" fill="url(#globeGradient)" opacity="0.7" />

            {/* Subtle latitude lines with curvature - more visible */}
            {[-240, -160, -80, 0, 80, 160, 240].map((y, i) => (
              <ellipse
                key={`lat-${i}`}
                cx="0"
                cy={y}
                rx={Math.sqrt(160000 - y * y)}
                ry={Math.abs(y) * 0.14}
                fill="none"
                stroke="rgba(255,255,255,0.05)"
                strokeWidth="0.4"
                opacity="0.8"
              />
            ))}

            {/* Subtle longitude lines - more visible */}
            {Array.from({ length: 16 }).map((_, i) => (
              <ellipse
                key={`lon-${i}`}
                cx="0"
                cy="0"
                rx="400"
                ry="400"
                fill="none"
                stroke="rgba(255,255,255,0.04)"
                strokeWidth="0.4"
                transform={`rotate(${i * 11.25})`}
                opacity="0.7"
              />
            ))}

            {/* World map topology - more visible contour layers */}
            <g opacity="0.15" fill="none" stroke="url(#topologyGradient)" strokeWidth="0.5">
              {/* North America topology */}
              <ellipse cx="-130" cy="70" rx="95" ry="135" />
              <ellipse cx="-130" cy="70" rx="75" ry="115" />
              <ellipse cx="-130" cy="70" rx="55" ry="90" />
              <ellipse cx="-130" cy="70" rx="35" ry="65" />

              {/* Europe topology */}
              <ellipse cx="50" cy="35" rx="55" ry="45" />
              <ellipse cx="50" cy="35" rx="40" ry="30" />
              <ellipse cx="50" cy="35" rx="25" ry="18" />

              {/* Asia topology */}
              <ellipse cx="180" cy="45" rx="140" ry="95" />
              <ellipse cx="180" cy="45" rx="115" ry="75" />
              <ellipse cx="180" cy="45" rx="90" ry="55" />
              <ellipse cx="180" cy="45" rx="65" ry="35" />

              {/* Africa topology */}
              <ellipse cx="50" cy="150" rx="85" ry="125" />
              <ellipse cx="50" cy="150" rx="65" ry="100" />
              <ellipse cx="50" cy="150" rx="45" ry="75" />

              {/* South America topology */}
              <ellipse cx="-80" cy="210" rx="60" ry="110" />
              <ellipse cx="-80" cy="210" rx="45" ry="85" />

              {/* Australia topology */}
              <ellipse cx="220" cy="200" rx="50" ry="45" />
              <ellipse cx="220" cy="200" rx="35" ry="30" />
            </g>

            {/* Tiny gold acquisition nodes - more visible */}
            {[
              { x: -120, y: 95, name: "NYC", delay: 0 },
              { x: -95, y: 130, name: "MIA", delay: 0.5 },
              { x: 50, y: 50, name: "LDN", delay: 1 },
              { x: 45, y: 85, name: "PAR", delay: 1.5 },
              { x: 60, y: 145, name: "DXB", delay: 2 },
              { x: 180, y: 65, name: "TYO", delay: 2.5 },
              { x: 160, y: 95, name: "SGP", delay: 3 },
              { x: 130, y: 50, name: "HKG", delay: 3.5 },
              { x: 220, y: 195, name: "SYD", delay: 4 },
              { x: -90, y: 200, name: "SAO", delay: 4.5 },
              { x: 75, y: 60, name: "FRA", delay: 5 },
              { x: -140, y: 110, name: "LAX", delay: 5.5 },
            ].map((city) => (
              <g key={city.name} opacity="0.6">
                {/* Tiny precise node */}
                <circle
                  cx={city.x}
                  cy={city.y}
                  r="1"
                  fill="#D4AF37"
                >
                  <animate
                    attributeName="opacity"
                    values="0.4;0.8;0.4"
                    dur="5s"
                    begin={`${city.delay}s`}
                    repeatCount="indefinite"
                  />
                </circle>
                {/* Subtle pulse ring */}
                <circle
                  cx={city.x}
                  cy={city.y}
                  r="2"
                  fill="none"
                  stroke="#D4AF37"
                  strokeWidth="0.2"
                  opacity="0.3"
                >
                  <animate
                    attributeName="r"
                    values="2;5;2"
                    dur="5s"
                    begin={`${city.delay}s`}
                    repeatCount="indefinite"
                  />
                  <animate
                    attributeName="opacity"
                    values="0.2;0.4;0.2"
                    dur="5s"
                    begin={`${city.delay}s`}
                    repeatCount="indefinite"
                  />
                </circle>
              </g>
            ))}

            {/* Subtle neural connection paths - more visible */}
            <g opacity="0.12">
              {/* Transatlantic intelligence corridor */}
              <path
                d="M -120,95 Q -30,55 50,50"
                fill="none"
                stroke="url(#neuralPathGradient)"
                strokeWidth="0.4"
                strokeDasharray="3,10"
              >
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="13"
                  dur="8s"
                  repeatCount="indefinite"
                />
              </path>

              {/* Europe to Middle East */}
              <path
                d="M 50,50 Q 55,85 60,145"
                fill="none"
                stroke="url(#neuralPathGradient)"
                strokeWidth="0.4"
                strokeDasharray="3,10"
              >
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="13"
                  dur="9s"
                  repeatCount="indefinite"
                />
              </path>

              {/* Asia Pacific network */}
              <path
                d="M 60,145 Q 110,110 160,95"
                fill="none"
                stroke="url(#neuralPathGradient)"
                strokeWidth="0.4"
                strokeDasharray="3,10"
              >
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="13"
                  dur="8.5s"
                  repeatCount="indefinite"
                />
              </path>

              {/* Tokyo to Sydney */}
              <path
                d="M 180,65 Q 200,125 220,195"
                fill="none"
                stroke="url(#neuralPathGradient)"
                strokeWidth="0.4"
                strokeDasharray="3,10"
              >
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="13"
                  dur="10s"
                  repeatCount="indefinite"
                />
              </path>

              {/* London to Hong Kong */}
              <path
                d="M 50,50 Q 90,48 130,50"
                fill="none"
                stroke="url(#neuralPathGradient)"
                strokeWidth="0.4"
                strokeDasharray="3,10"
              >
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="13"
                  dur="11s"
                  repeatCount="indefinite"
                />
              </path>

              {/* NYC to LAX */}
              <path
                d="M -120,95 Q -130,102 -140,110"
                fill="none"
                stroke="url(#neuralPathGradient)"
                strokeWidth="0.4"
                strokeDasharray="3,10"
              >
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="13"
                  dur="7s"
                  repeatCount="indefinite"
                />
              </path>

              {/* Dubai to Singapore */}
              <path
                d="M 60,145 Q 95,125 130,105"
                fill="none"
                stroke="url(#neuralPathGradient)"
                strokeWidth="0.4"
                strokeDasharray="3,10"
              >
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="13"
                  dur="9.5s"
                  repeatCount="indefinite"
                />
              </path>
            </g>

            {/* Subtle atmospheric glow */}
            <circle cx="0" cy="0" r="420" fill="url(#atmosphereGlow)" />

            {/* Subtle edge definition */}
            <circle
              cx="0"
              cy="0"
              r="400"
              fill="none"
              stroke="rgba(255,255,255,0.04)"
              strokeWidth="0.5"
            />
          </svg>
        </motion.div>

        {/* Soft moving grid lines - more visible */}
        <div className="absolute inset-0 opacity-12">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-px h-20 bg-gradient-to-b from-transparent via-white/12 to-transparent"
              style={{
                left: `${20 + i * 12}%`,
                top: `-5%`,
              }}
              animate={{
                y: ["0vh", "105vh"],
              }}
              transition={{
                duration: 30 + i * 6,
                repeat: Infinity,
                delay: i * 7,
                ease: "linear",
              }}
            />
          ))}
        </div>

        {/* Horizontal data streams - more visible */}
        <div className="absolute inset-0 opacity-[0.08]">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={`h-${i}`}
              className="absolute h-px w-32 bg-gradient-to-r from-transparent via-white/25 to-transparent"
              style={{
                top: `${30 + i * 20}%`,
                left: `-10%`,
              }}
              animate={{
                x: ["0vw", "110vw"],
              }}
              transition={{
                duration: 40 + i * 10,
                repeat: Infinity,
                delay: i * 8,
                ease: "linear",
              }}
            />
          ))}
        </div>

        {/* Softer vignette - allow more visibility */}
        <div className="absolute inset-0 bg-gradient-radial from-transparent via-black/30 to-black/75" />
      </motion.div>

      {/* Content - typography is primary focus */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
        >
          <h1 className="text-[120px] leading-[1.1] font-bold text-white mb-8 tracking-tight drop-shadow-2xl">
            Autonomous<br />
            Intelligence for<br />
            Global Real Estate
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto font-light drop-shadow-lg">
            Neural agents analyzing markets, detecting opportunities, and executing
            real estate intelligence workflows at institutional scale
          </p>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1.5 }}
        className="absolute bottom-12 left-1/2 transform -translate-x-1/2"
      >
        <div className="flex flex-col items-center space-y-2">
          <span className="text-xs text-gray-400 uppercase tracking-widest">Scroll to Explore</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-[1px] h-12 bg-gradient-to-b from-gray-400 to-transparent"
          />
        </div>
      </motion.div>
    </section>
  );
}
